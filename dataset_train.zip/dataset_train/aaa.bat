# UTF-8 から Shift-JIS に変換
Get-ChildItem -Path "." -Filter "*.csv" | ForEach-Object {
    $content = Get-Content $_.FullName -Encoding UTF8
    Set-Content $_.FullName -Value $content -Encoding Default
}